clc
clear
close all
addpath Proposed
addpath quality_assess
addpath Data


%% Data loading
% load PaviaU.mat
% simu_indian = paviaU./max(paviaU(:));
% Omsi       = simu_indian(1:256,1:256,:); 
load simu_indian
Omsi = simu_indian;

dim   = size(Omsi);
[M,N,p]   = size(Omsi);
%[S U sv_ori tol] = hosvd(Omsi, [1 1 1], 1e-6);

%% Gaussian + Impulse noise
    % Gaussian
noiselevel= 0.05*ones(1,p); 
Nmsi_gaussian = Omsi;
   for i =1:p
        Nmsi_gaussian(:,:,i)=Omsi(:,:,i)  + noiselevel(i)*randn(M,N);
   end

    % S&P noise
noiselevel_SP = 0.05*rand(1,p); 
   for i = 1:p
        Nmsi_Gau_pepper(:,:,i)=imnoise(Nmsi_gaussian(:,:,i),'salt & pepper',noiselevel(i));
   end
figure;imshow(Nmsi_Gau_pepper(:,:,5))   
[psnr_noise, ssim_noise, fsim_noise, ergas_noise, msam_noise] = MSIQA(Omsi*255,Nmsi_Gau_pepper*255);


%% HOSVD
[S U sv_Gau_pepper tol] = hosvd(Nmsi_Gau_pepper, [1 1 1], [20 20 40]);

S_re = tprod(S, U);
 figure;imshow(S_re(:,:,5))
[psnr_HOSVD, ssim_HOSVD, fsim_HOSVD, ergas_HOSVD, msam_HOSVD] = MSIQA(Omsi*255,S_re*255);

%%

%% MGLRTA
alpha = [0, 0, 0];
%alpha = alpha / sum(alpha);

maxIter = 500;
epsilon = 1e-5;

rho = 1e-1;
tao = 1e-3;
deta = [1e-1,1e-1,1e-3];
%deta = [0,0,0];
 k = 3;
 dim = size(Nmsi_Gau_pepper);
%  for i =1:length(dim)
%     W_new{i} = zeros(dim{i});
%     Degree{i} = W_new{i};
%     L{i} = W_new{i};
% end
W_new = cell(length(dim), 1);
for i =1:length(dim)
    for j =1:dim(i)%-k
    W(j,j) = 0; 
    W(j,j+1:j+k) = 1; 
    W(j+1:j+k,j) = 1;       
    end
    W_new{i} = W(1:dim(i),1:dim(i));
    Degree{i}=diag((sum(W_new{i},2)));
        L{i} = Degree{i}-W_new{i};
end

 [X, errList] = GLTC_graph_denoising(Nmsi_Gau_pepper, L,alpha, rho,deta, tao,maxIter, epsilon);
 figure;imshow(X(:,:,5),[])
[psnr_MGLRTA, ssim_MGLRTA, fsim_MGLRTA, ergas_MGLRTA, msam_MGLRTA] = MSIQA(Omsi*255,X*255);


%% High Accuracy LRTC (solve the original problem, HaLRTC algorithm in the paper)
 alpha = [1, 1, 1e3];
%alpha = alpha / sum(alpha);

maxIter = 500;
epsilon = 1e-5;

%
rho = 1e-1;
[X_LRTC, errList_LRTC] = HaLRTC_denoising(...
    Nmsi_Gau_pepper, ...                % a tensor whose elements in Omega are used for estimating missing value
    alpha,...                % the coefficient of the objective function, i.e., \|X\|_* := \alpha_i \|X_{i(i)}\|_* 
    rho,...                  % the initial value of the parameter; it should be small enough  
    maxIter,...              % the maximum iterations
    epsilon...               % the tolerance of the relative difference of outputs of two neighbor iterations 
    );
[psnr_LRTC, ssim_LRTC, fsim_LRTC, ergas_LRTC, msam_LRTC] = MSIQA(Omsi*255,X_LRTC*255);
figure;imagesc(X_LRTC(:,:,5));title('LRTC')
 


