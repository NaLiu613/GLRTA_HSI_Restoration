clc
clear
close all
addpath Proposed
addpath quality_assess
addpath Data


%% Data loading
load PaviaU.mat
simu_indian = paviaU./max(paviaU(:));
Omsi       = simu_indian(1:256,1:256,:); 
dim   = size(Omsi);
[M,N,p]   = size(Omsi);
[S U sv_ori tol] = hosvd(Omsi, [1 1 1], 1e-6);

figure(1)
set(gcf,'Position',[101,101,312,312]) 
axes('Position',[0,0,1,1])
imshow(Omsi(:,:,50),[]),axis image,axis off

print -depsc HSI_Clean

figure(1)
set(gcf,'Position',[101,101,312,212])
colormap jet
axes('Position',[0,0,1,1])
plot(sv_ori{1, 1}(1:30))

print -depsc ori_mode1

figure(2)
set(gcf,'Position',[101,101,312,212])
colormap jet
axes('Position',[0,0,1,1])
plot(sv_ori{1, 2}(1:30))
print -depsc ori_mode2

figure(3)
set(gcf,'Position',[101,101,312,212])
colormap jet
axes('Position',[0,0,1,1])
plot(sv_ori{1, 3}(1:30))
print -depsc ori_mode3


%% Gaussian noise
noiselevel = 0.15*ones(1,p); 
Nmsi_gaussian = Omsi;
   for i =1:p
        Nmsi_gaussian(:,:,i)=Omsi(:,:,i)  + noiselevel(i)*randn(M,N);
   end

%  S&P noise
   for i = 1:p
        Nmsi_Gau_pepper(:,:,i)=imnoise(Nmsi_gaussian(:,:,i),'salt & pepper',noiselevel(i));
   end
   
figure(1)
set(gcf,'Position',[101,101,312,312]) 

axes('Position',[0,0,1,1])
imshow(Nmsi_Gau_pepper(:,:,50),[]),axis image,axis off
print -depsc HSI_Gau_Salt_Pepper

[S U sv_Gau_pepper tol] = hosvd(Nmsi_Gau_pepper, [1 1 1], 1e-6);

figure(1)
set(gcf,'Position',[101,101,312,212])
colormap jet
plot(sv_Gau_pepper{1, 1}(1:30))

print -depsc noise_mode1


figure(2)
set(gcf,'Position',[101,101,312,212])
colormap jet
plot(sv_Gau_pepper{1, 2}(1:30))
print -depsc noise_mode2

figure(3)
set(gcf,'Position',[101,101,312,212])
colormap jet
plot(sv_Gau_pepper{1, 3}(1:30))
print -depsc noise_mode3




 %% stripes
 rate = 0.5;
 Mean = 0.5;%std(DataTest(:))% (10/255)/max(DataTest(:));%;
 [Nmsi_stripes,loc]  =  make_stripes(Omsi,rate,Mean);
   
figure(1)
set(gcf,'Position',[101,101,312,312]) 
axes('Position',[0,0,1,1])
imshow(Nmsi_stripes(:,:,50),[]),axis image,axis off
print -depsc HSI_stripes
   
[S U sv_strip tol] = hosvd(Nmsi_stripes, [1 1 1], 1e-6);

figure(1)
set(gcf,'Position',[101,101,312,212])
colormap jet
plot(sv_strip{1, 1}(1:30))

print -depsc stripes_mode1


figure(2)
set(gcf,'Position',[101,101,312,212])
colormap jet
plot(sv_strip{1, 2}(1:30))
print -depsc stripes_mode2

figure(3)
set(gcf,'Position',[101,101,312,212])
colormap jet
plot(sv_strip{1, 3}(1:30))
print -depsc stripes_mode3

%% patches

Omega_patch = ones(M,N,p);
Omega_patch([70:90],[70:90],:) = 0;
Omega_patch([180:190],[150:160],:) = 0;
Nmsi_patch = Omega_patch.*Omsi;
 
figure(1)
set(gcf,'Position',[101,101,312,312]) 
axes('Position',[0,0,1,1])
Nmsi_patch([70:90],[70:90],:) = 1;
Nmsi_patch([180:190],[150:160],:) = 1;
imshow(Nmsi_patch(:,:,50),[]),axis image,axis off
print -depsc HSI_Patches

[S U sv_patch tol] = hosvd(Nmsi_patch, [1 1 1], 1e-6);

%sv = [sv_ori{1};sv_strip{1};sv_patch{1},];

%%
Nmsi_band = Omsi;
Nmsi_band(:,:,[10,50,100])=0;
[S U sv_band tol] = hosvd(Nmsi_band, [1 1 1], 1e-6);
figure(1)
set(gcf,'Position',[101,101,312,312]) 
imagesc(Nmsi_band(:,:,50)),axis image,axis off
print -depsc HSI_SpectralAbsorption

sv = [sv_ori{1},sv_Gau_pepper{1},sv_strip{1},sv_patch{1},sv_band{1}];
figure(2)
set(gcf,'Position',[101,101,312,212])
bar(sv(1:5,:))
legend('Clean Image','Gaussian+Impulse','Stripes','Patches','Spectral Absorption')
print -depsc rank_mode1

sv = [sv_ori{2},sv_Gau_pepper{2},sv_strip{2},sv_patch{2},sv_band{2}];
figure(2)
set(gcf,'Position',[101,101,312,212])
bar(sv(1:5,:))
legend('Clean Image','Gaussian+Impulse','Stripes','Patches','Spectral Absorption')
print -depsc rank_mode2

sv = [sv_ori{3}(1:10),sv_Gau_pepper{3}(1:10),sv_strip{3}(1:10),sv_patch{3}(1:10),sv_band{3}(1:10)];
figure(2)
set(gcf,'Position',[101,101,312,212])
bar(sv(1:5,:))
legend('Clean Image','Gaussian+Impulse','Stripes','Patches','Spectral Absorption')
print -depsc rank_mode3


figure(1)
set(gcf,'Position',[101,101,512,512],'Color',[1 1 1])
%set(gca,'LineWidth',1)
set(gca,'FontName','Arial','FontSize',10,'FontWeight','bold' )
colormap jet
heatmap(W{1, 1}(1:15,1:15));
%set(gca,'GridLineStyle',':','GridColor','k', 'GridAlpha',0.8)


