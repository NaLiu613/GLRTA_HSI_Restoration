clc
clear
close all
addpath Proposed
addpath quality_assess
addpath Data


%% Data loading
load PaviaU.mat
paviau = paviaU./max(paviaU(:));
Omsi       = paviau(1:256,1:256,:); 
[M,N,p]   = size(Omsi);


 %% stripes
 rate = 0.5;
 Mean = mean(Omsi(:));% (10/255)/max(DataTest(:));%;
 [Nmsi,loc]  =  make_stripes(Omsi,rate,Mean);

Omega3 = ones(M,N*p);
Omega3(:,loc) = 0;
Omega3_3D = reshape(Omega3,[M,N,p]);
Omega3_3D(:,[50 51 100 200],:) = 0;
OMEGA3 =logical (Omega3_3D);

I1 = Omsi - min(Omsi(:));
I1 = I1 ./ max(I1(:));
image = I1;
 
mask =Omega3_3D;


save('inpainting_PaviaU_05.mat','image','mask');

Data = Nmsi.*OMEGA3;
[psnr_stripes, ssim_stripes, fsim_stripes, ergas_stripes, msam_stripes] = MSIQA(Omsi*255,Data*255);

%%
%alpha = alpha / sum(alpha);
epsilon = 1e-5;

%% Graph construction
%Method 1: KNN

% dim = size(Data);
% options.NeighborMode = 'KNN';
% options.k = 7;
% options.WeightMode = 'Binary';
% 
%     for i = 1:ndims(Data)
%         fea{i} = Unfold(Data, dim, i);
%         W{i} = constructW(fea{i},options);
%      %   W{i} = (C{i}+C{i}')/2;
%        W{i} = W{i}./ repmat(sum(W{i},1),dim(i),1);
%           L{i}= eye(dim(i),dim(i))-W{i};
%      %  Degree{i}=diag((sum(W{i},2)));
%      %  L{i} = Degree{i}-W{i};
%     end
% 
    %Method3:
 k = 3;
 dim = size(Data);
%  for i =1:length(dim)
%     W_new{i} = zeros(dim{i});
%     Degree{i} = W_new{i};
%     L{i} = W_new{i};
% end
W_new = cell(length(dim), 1);
for i =1:length(dim)
    for j =1:dim(i)%-k
    W(j,j) = 0; 
    W(j,j+1:j+k) = 1; 
    W(j+1:j+k,j) = 1;       
    end
    W_new{i} = W(1:dim(i),1:dim(i));
    Degree{i}=diag((sum(W_new{i},2)));
        L{i} = Degree{i}-W_new{i};
end

%%
maxIter = 500;
alpha = [1e0, 1e0, 1e3];
%alpha = alpha / sum(alpha);

rho = 1e-1;
tao = 1e-3;
deta = [1e1,1e1,1e-3];

[X_GLTC_graph, errList] = GLTC_graph(Data, OMEGA3,L,alpha, rho,deta, tao, maxIter, epsilon);
%X_GLTC_graph(OMEGA3==1)=Omsi(OMEGA3==1);

[psnr_GLTC_graph, ssim_GLTC_graph, fsim_GLTC_graph, ergas_GLTC_graph, msam_GLTC_graph] = MSIQA(Omsi*255,X_GLTC_graph*255);
figure;imagesc(X_GLTC_graph(:,:,band));title('LRTC-graph')

