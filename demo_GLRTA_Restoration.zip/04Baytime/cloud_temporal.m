clc
clear
close all
addpath Proposed
addpath quality_assess
addpath Data


%% Data loading
load bayArea_mat_Bay_Area_2015.mat
Bay_2015 = HypeRvieW;
load Bay_Area_2013.mat
Bay_2013 = HypeRvieW;
Bay (:,:,:,1) = Bay_2013(1:256,1:256,:);
Bay (:,:,:,2) = Bay_2015(1:256,1:256,:);

load Mask_cloud
Omsi = Bay./max(Bay(:));
[M,N,p,t]   = size(Omsi);

 %% cloud
OMEGA3 = logical(ones(M,N,p,t));
time1 = logical(repmat(Mask_256,[1,1,p]));
OMEGA3(:,:,:,1) = time1;

Bay1 = Bay (:,:,:,1);

I1 = Bay1 - min(Bay1(:));
I1 = I1 ./ max(I1(:));
image = I1;
 

mask = double(OMEGA3(:,:,:,1));
save('inpainting_Bay.mat','image','mask');

Data = Omsi.*OMEGA3;

band = 50;
figure;imagesc(Omsi(:,:,band,1));title('Clean')
figure;imagesc(OMEGA3(:,:,band+1,1));title('OMEGA3')
figure;imagesc(Data(:,:,band,1));title('Noisy')

[psnr_noise, ssim_noise, fsim_noise, ergas_noise, msam_noise] = MSIQA(Omsi(:,:,:,1)*255,Data(:,:,:,1)*255);

%%
epsilon = 1e-5;

%%
 k = 7;
 dim = size(Data);
%  for i =1:length(dim)
%     W_new{i} = zeros(dim{i});
%     Degree{i} = W_new{i};
%     L{i} = W_new{i};
% end
W_new = cell(length(dim), 1);
for i =1:length(dim)
    for j =1:dim(i)%-k
    W(j,j) = 0; 
    W(j,j+1:j+k) = 1; 
    W(j+1:j+k,j) = 1;       
    end
    W_new{i} = W(1:dim(i),1:dim(i));
    Degree{i}=diag((sum(W_new{i},2)));
        L{i} = Degree{i}-W_new{i};
end

maxIter = 500;
alpha = [1e0, 1e0, 1e0,1e0];
%alpha = [0, 0, 0];
%alpha = alpha / sum(alpha);

rho = 1e-1;
tao = 1e-3;
deta = [1e-1,1e-1,1e-1,1e-1];
[X_GLTC_graph, errList] = GLTC_graph(Data, OMEGA3,L,alpha, rho,deta, tao, maxIter, epsilon);
X_GLTC_graph(OMEGA3==1)=Omsi(OMEGA3==1);
[psnr_GLTC_graph, ssim_GLTC_graph, fsim_GLTC_graph, ergas_GLTC_graph, msam_GLTC_graph] = MSIQA(Omsi*255,X_GLTC_graph*255);
figure;imagesc(X_GLTC_graph(:,:,band,1));title('LRTC-graph')

