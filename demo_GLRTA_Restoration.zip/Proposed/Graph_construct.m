function [W,Degree,L] = Graph_construct(Data,OMEGA3)
dim = size(Data);


options.NeighborMode = 'KNN';
options.k = 7;
options.WeightMode = 'Binary';
options.bSelfConnected = 0;
options.bTrueKNN = 0;

    for i = 1:ndims(Data)
        fea{i} = Unfold(Data, dim, i);
        C{i} = constructW(fea{i},options);
        W{i} = (C{i}+C{i}')/2;
       % W{i} = W{i}./ repmat(sum(W{i},1),dim(i),1);
      %  Degree{i}=diag((sum(W{i},2)))-diag(diag(W{i}));
      %  Degree_21{i} = Degree{i}.*(-0.5);
      %  L{i} = eye(dim(i),dim(i))-Degree_21{i}*W{i}*Degree_21{i};
       % W{i} = W{i}./ repmat(sum(W{i},1),dim(i),1);
       %   L{i}= eye(dim(i),dim(i))-W{i};
        Degree{i}=diag((sum(W{i},2)));
        L{i} = Degree{i}-W{i};
    end
end