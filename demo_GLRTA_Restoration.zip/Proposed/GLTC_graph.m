%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ADM algorithm: tensor completion
% paper: Tensor completion for estimating missing values in visual data
% date: 05-22-2011
% min_X: \sum_i \alpha_i \|X_{i(i)}\|_*
% s.t.:  X_\Omega = T_\Omega
% 20210818: revised by na liu for geometry test 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [X, errList] = GLTC_graph(Image, Omega, L,alpha, rho,deta, tao,maxIter, epsilon)

if nargin < 10
    X = Image;
   X(logical(1-Omega)) = mean(Image(Omega));  

   % X(logical(1-Omega)) = 10;
end

errList = zeros(maxIter, 1);
dim = size(Image);
Z = cell(ndims(Image), 1);
T = Z;  

%% Z: Auxiliary var
%% T: Lagrangian multiplier
normT = norm(Image(:));
for i = 1:ndims(Image)
    Z{i} = X;
    T{i} = zeros(dim);
   % X{i} = X;
end

Xsum = zeros(dim);
for k = 1: maxIter
%     if mod(k, 20) == 0
%         fprintf('GLTC-graph: iterations = %d   difference=%f\n', k, errList(k-1));
%     end
 rho = rho * 1.05;
    % update Y

    Xsum = 0*Xsum;
    for i = 1:ndims(Image)
        Z{i} = Fold(Pro2TraceNorm(Unfold(X - T{i}/rho, dim, i), alpha(i)/rho), dim, i);
    end  

    lastX = X;
   % X = (Msum + beta*Ysum) / (ndims(T)*beta);
    for i = 1:ndims(Image)
           var0{i} = Fold(pinv(deta(i)*(L{i})+(rho+tao)*eye(dim(i)))*Unfold((rho*Z{i}+T{i}+tao*Image), dim, i), dim, i);
         %  X{i} = var0{i};
          Xsum = Xsum + var0{i};
    end
    X = Xsum/ndims(Image);  
      
          X(Omega) = Image(Omega);  
    % update Lagrangian Multiplier
      
    for i = 1:ndims(Image)
        T{i} = T{i} + rho*(Z{i}-X);
 
    end 
    % compute the error
    errList(k) = norm(X(:)-lastX(:)) / normT;
    if errList(k) < epsilon
        break;
    end
end

%errList = errList(1:k);
%fprintf('GLTC ends: total iterations = %d   difference=%f\n\n', k, errList(k));

