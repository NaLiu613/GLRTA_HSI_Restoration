function [D1,D2,div1,div2]=construction_total_variation(m,n)
temp=[-ones(m-1,1),[0;ones(m-2,1)];0,1];
temp2=repmat(temp,[n,1]);
D1=spdiags(temp2,[0,1],m*n,m*n);
temp=[-ones(1,m*(n-1)),zeros(1,m)]';
temp2=[zeros(m,1);ones(m*(n-1),1)];
temp3=[temp,temp2];
D2=spdiags(temp3,[0,m],m*n,m*n);

temp=[ones(m-1,1),-ones(m-1,1);0,0];
temp2=repmat(temp,[n,1]);
div1=spdiags(temp2,[0,-1],m*n,m*n);



temp=[ones(1,m*(n-1)),zeros(1,m)]';
temp2=[-ones(m*(n-1),1);zeros(m,1)];
temp3=[temp,temp2];
div2=spdiags(temp3,[0,-m],m*n,m*n);

end