band = [5 2 1];
ratio = 8;
close all
 ywidth=100;   xheight=300;   width=80;   height=80;
 pos=[ywidth xheight width height];%
 
     ywidth2=1;    xheight2=1;    width2=width;    height2=height;

%%
figure(3)
Image = Omsi;
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imagesc(Image(:,:,band) ),axis image, axis off

 hold on

    drawRectangleImage = rectangle('Position',[ywidth,xheight,width,height],'LineWidth',1.5,'EdgeColor','r');
    hold off    
   imCp = imcrop( Image(:,:,band), pos ); %�ü�
    hold on
   axes('Position',[0.6,0,0.4,0.4])
   %imshow(imCp,[])%,'position', pos);
     imagesc(imCp),axis image, axis off      
    hold on

    drawRectangleImage = rectangle('Position',[ywidth2,xheight2,width2,height2],'LineWidth',1.5,'EdgeColor','r');
    hold off
print -depsc Landsat_ori


%%
Image = Data;

figure(4)
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imagesc(Image(:,:,band)),axis image, axis off
 hold on

    drawRectangleImage = rectangle('Position',[ywidth,xheight,width,height],'LineWidth',1.5,'EdgeColor','r');
    hold off    
   imCp = imcrop( Image(:,:,band), pos ); %�ü�
    hold on
   axes('Position',[0.6,0,0.4,0.4])
   %imshow(imCp,[])%,'position', pos);
     imagesc(imCp),axis image, axis off      
    hold on

    drawRectangleImage = rectangle('Position',[ywidth2,xheight2,width2,height2],'LineWidth',1.5,'EdgeColor','r');
    hold off
print -depsc Landsat_stripes

%%
Image = X_GLTC_graph;

figure(5)
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imagesc(Image(:,:,band)),axis image, axis off

 hold on

    drawRectangleImage = rectangle('Position',[ywidth,xheight,width,height],'LineWidth',1.5,'EdgeColor','r');
    hold off    
   imCp = imcrop( Image(:,:,band), pos ); %�ü�
    hold on
   axes('Position',[0.6,0,0.4,0.4])
   %imshow(imCp,[])%,'position', pos);
     imagesc(imCp),axis image, axis off      
    hold on

    drawRectangleImage = rectangle('Position',[ywidth2,xheight2,width2,height2],'LineWidth',1.5,'EdgeColor','r');
    hold off
print -depsc Landsat_GLRTA

%%
Image = X_LRTC;

figure(6)
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imagesc(Image(:,:,band)),axis image, axis off

 hold on

    drawRectangleImage = rectangle('Position',[ywidth,xheight,width,height],'LineWidth',1.5,'EdgeColor','r');
    hold off    
   imCp = imcrop( Image(:,:,band), pos ); %�ü�
    hold on
   axes('Position',[0.6,0,0.4,0.4])
   %imshow(imCp,[])%,'position', pos);
     imagesc(imCp),axis image, axis off      
    hold on

    drawRectangleImage = rectangle('Position',[ywidth2,xheight2,width2,height2],'LineWidth',1.5,'EdgeColor','r');
    hold off
print -depsc Landsat_HaLRTC

%%
Image = LRTV_image;

figure(7)
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imagesc(Image(:,:,band)),axis image, axis off

 hold on

    drawRectangleImage = rectangle('Position',[ywidth,xheight,width,height],'LineWidth',1.5,'EdgeColor','r');
    hold off    
   imCp = imcrop( Image(:,:,band), pos ); %�ü�
    hold on
   axes('Position',[0.6,0,0.4,0.4])
   %imshow(imCp,[])%,'position', pos);
     imagesc(imCp),axis image, axis off      
    hold on

    drawRectangleImage = rectangle('Position',[ywidth2,xheight2,width2,height2],'LineWidth',1.5,'EdgeColor','r');
    hold off
print -depsc Landsat_LRTV

%%
Image = LRTDGS_rec;

figure(8)
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imagesc(Image(:,:,band)),axis image, axis off

 hold on

    drawRectangleImage = rectangle('Position',[ywidth,xheight,width,height],'LineWidth',1.5,'EdgeColor','r');
    hold off    
   imCp = imcrop( Image(:,:,band), pos ); %�ü�
    hold on
   axes('Position',[0.6,0,0.4,0.4])
   %imshow(imCp,[])%,'position', pos);
     imagesc(imCp),axis image, axis off      
    hold on

    drawRectangleImage = rectangle('Position',[ywidth2,xheight2,width2,height2],'LineWidth',1.5,'EdgeColor','r');
    hold off
print -depsc Landsat_LRTDGS

%%
Image = E_Img;

figure(9)
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imagesc(Image(:,:,band)),axis image, axis off

 hold on

    drawRectangleImage = rectangle('Position',[ywidth,xheight,width,height],'LineWidth',1.5,'EdgeColor','r');
    hold off    
   imCp = imcrop( Image(:,:,band), pos ); %�ü�
    hold on
   axes('Position',[0.6,0,0.4,0.4])
   %imshow(imCp,[])%,'position', pos);
     imagesc(imCp),axis image, axis off      
    hold on

    drawRectangleImage = rectangle('Position',[ywidth2,xheight2,width2,height2],'LineWidth',1.5,'EdgeColor','r');
    hold off
print -depsc Landsat_WLRTR

%%
Image = output_image;

figure(10)
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imagesc(Image(:,:,band)),axis image, axis off

 hold on

    drawRectangleImage = rectangle('Position',[ywidth,xheight,width,height],'LineWidth',1.5,'EdgeColor','r');
    hold off    
   imCp = imcrop( Image(:,:,band), pos ); %�ü�
    hold on
   axes('Position',[0.6,0,0.4,0.4])
   %imshow(imCp,[])%,'position', pos);
     imagesc(imCp),axis image, axis off      
    hold on

    drawRectangleImage = rectangle('Position',[ywidth2,xheight2,width2,height2],'LineWidth',1.5,'EdgeColor','r');
    hold off
print -depsc Landsat_TRLRF_CTV

%%
Image = double(pred);

figure(10)
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imagesc(Image(:,:,band)),axis image, axis off

 hold on

    drawRectangleImage = rectangle('Position',[ywidth,xheight,width,height],'LineWidth',1.5,'EdgeColor','r');
    hold off    
   imCp = imcrop( Image(:,:,band), pos ); %�ü�
    hold on
   axes('Position',[0.6,0,0.4,0.4])
   %imshow(imCp,[])%,'position', pos);
     imagesc(imCp),axis image, axis off      
    hold on

    drawRectangleImage = rectangle('Position',[ywidth2,xheight2,width2,height2],'LineWidth',1.5,'EdgeColor','r');
    hold off
print -depsc Landsat_DIP


%% ===========================err
band = 5;

Image_err = abs(image - double(pred));
Image_err = Image_err(:,:,band);
Image_err = Image_err./max(Image_err(:));
figure(33)
set(gcf,'color','white'); 
set(gcf,'Position',[101,101,356,356])
colormap jet
 cmap = colormap;
% map = cmap([1,4,7,11,14,17,21,24,28,30,33,35,37,40,43,47,50,53,56,58,60,64],:);
axes('Position',[0,0,1,1])
% colormap(map);
% caxis([0,0.6]);
imagesc(Image_err),axis image, axis off
print -depsc Landsat_DIP_err


%%
Image_err = abs(Omsi - Data);
Image_err = Image_err(:,:,band);
Image_err = Image_err./max(Image_err(:));
figure(22)
set(gcf,'color','white'); 
set(gcf,'Position',[101,101,356,356])
colormap jet
% cmap = colormap;
% map = cmap([1,4,7,11,14,17,21,24,28,30,33,35,37,40,43,47,50,53,56,58,60,64],:);
axes('Position',[0,0,1,1])
% colormap(map);
%caxis([0,0.6]);
imagesc(Image_err),axis image, axis off
print -depsc Landsat_stripes_err

%%
Image_err = abs(Omsi - X_GLTC_graph);
Image_err = Image_err(:,:,band);
Image_err = Image_err./max(Image_err(:));
figure(33)
set(gcf,'color','white'); 
set(gcf,'Position',[101,101,356,356])
colormap jet
 cmap = colormap;
% map = cmap([1,4,7,11,14,17,21,24,28,30,33,35,37,40,43,47,50,53,56,58,60,64],:);
axes('Position',[0,0,1,1])
% colormap(map);
% caxis([0,0.6]);
imagesc(Image_err),axis image, axis off
print -depsc Landsat_GLRTA_err
 
%%
Image_err = abs(Omsi - X_LRTC);
Image_err = Image_err(:,:,band);
Image_err = Image_err./max(Image_err(:));
figure(44)
set(gcf,'color','white'); 
set(gcf,'Position',[101,101,356,356])
colormap jet
%  cmap = colormap;
%  map = cmap([1,4,7,11,14,17,21,24,28,30,33,35,37,40,43,47,50,53,56,58,60,64],:);
axes('Position',[0,0,1,1])
%  colormap(map);
 % caxis([0,0.6]);
imagesc(Image_err),axis image, axis off
print -depsc Landsat_HaLRTC_err


%%
Image_err = abs(Omsi - LRTV_image);
Image_err = Image_err(:,:,band);
Image_err = Image_err./max(Image_err(:));
figure(55)
set(gcf,'color','white'); 
set(gcf,'Position',[101,101,356,356])
colormap jet
% cmap = colormap;
%  map = cmap([1,4,7,11,14,17,21,24,28,30,33,35,37,40,43,47,50,53,56,58,60,64],:);
axes('Position',[0,0,1,1])
%  colormap(map);
 % caxis([0,0.6]);
imagesc(Image_err),axis image, axis off
print -depsc Landsat_LRTV_err

%%
Image_err = abs(Omsi - LRTDGS_rec);
Image_err = Image_err(:,:,band);
Image_err = Image_err./max(Image_err(:));
figure(66)
set(gcf,'color','white'); 
set(gcf,'Position',[101,101,356,356])
colormap jet
%  cmap = colormap;
%  map = cmap([1,4,7,11,14,17,21,24,28,30,33,35,37,40,43,47,50,53,56,58,60,64],:);
axes('Position',[0,0,1,1])
%  colormap(map);
 % caxis([0,0.6]);
imagesc(Image_err),axis image, axis off
print -depsc Landsat_LRTDGS_err

%%
Image_err = abs(Omsi - E_Img);
Image_err = Image_err(:,:,band);
Image_err = Image_err./max(Image_err(:));
figure(77)
set(gcf,'color','white'); 
set(gcf,'Position',[101,101,356,356])
colormap jet
%  cmap = colormap;
%  map = cmap([1,4,7,11,14,17,21,24,28,30,33,35,37,40,43,47,50,53,56,58,60,64],:);
axes('Position',[0,0,1,1])
%  colormap(map);
%  caxis([0,0.6]);
imagesc(Image_err),axis image, axis off
print -depsc Landsat_WLRTR_err

%%
Image_err = abs(Omsi - output_image);
Image_err = Image_err(:,:,band);
Image_err = Image_err./max(Image_err(:));
figure(88)
set(gcf,'color','white'); 
set(gcf,'Position',[101,101,356,356])
colormap jet
%  cmap = colormap;
%  map = cmap([1,4,7,11,14,17,21,24,28,30,33,35,37,40,43,47,50,53,56,58,60,64],:);
axes('Position',[0,0,1,1])
%  colormap(map);
%  caxis([0,0.6]);
imagesc(Image_err),axis image, axis off
print -depsc Landsat_TRLRF_CTV_err

