clc
clear
addpath function
addpath quality_assess
addpath Data
%% Simulated Indian Pines dataset case 3 
% rng(1)
% load simu_indian
% load Indian_G_noiselevel_0_2
% load Indian_Impuse_ratio_0_2

%% Data loading
load LE71520182003140ASN00_3001_3512.mat
load LE07_L1TP_109018_20210727_20210727_01_RT_GM_3001_3512.mat
LE71520182003140ASN00_3001_3512 = double(LE71520182003140ASN00_3001_3512);
data = LE71520182003140ASN00_3001_3512./max(LE71520182003140ASN00_3001_3512(:));


I1 = data - min(data(:));
I1 = I1 ./ max(I1(:));
image = I1;
 
mask =double(LE07_L1TP_109018_20210727_20210727_01_RT_GM_3001_3512);

save('inpainting_Landsat.mat','image','mask');


Omsi       = data;%(:,:,5); 
[M,N,p]   = size(Omsi);

mask =logical (LE07_L1TP_109018_20210727_20210727_01_RT_GM_3001_3512);
OMEGA3 = mask;%(:,:,1);
Data = Omsi.*OMEGA3;
Nmsi = Data;
[psnr_stripes, ssim_stripes, fsim_stripes, ergas_stripes, msam_stripes] = MSIQA(Omsi*255,Data*255);
%%

epsilon = 1e-5;


%% Graph construction
% %Method 1: KNN
% [W,Degree,L] = Graph_construct(Data,OMEGA3);
% 
% 
% %Method2 2: TV    
% dim = size(Data);
%    for i = 1:ndims(Data)
%         D{i} = zeros(dim(i)-1,dim(i));   
%         for j = 1:dim(i)-1
%            D{i}(j,j) = -1;
%            D{i}(j,j+1) = 1;
%            
%          % W{i} = W{i}./ repmat(sum(W{i},1),dim(i),1);
%          % LD{i}= diag(sum(D{i},1))-D{i};
%        end
%    end
 k = 3;
 dim = size(Data);
%  for i =1:length(dim)
%     W_new{i} = zeros(dim{i});
%     Degree{i} = W_new{i};
%     L{i} = W_new{i};
% end
W_new = cell(length(dim), 1);
for i =1:length(dim)
    for j =1:dim(i)%-k
    W(j,j) = 0; 
    W(j,j+1:j+k) = 1; 
    W(j+1:j+k,j) = 1;       
    end
    W_new{i} = W(1:dim(i),1:dim(i));
    Degree{i}=diag((sum(W_new{i},2)));
        L{i} = Degree{i}-W_new{i};
end   
%%
maxIter = 500;
alpha = [1e1, 1e1, 1e0];
%alpha = alpha / sum(alpha);

rho = 1e-1;%1e-5;
tao = 1e-3;
deta = [3e0,3e0,3e-3];%1e-1*rho.*[1e0,1e0,1e0];
[X_GLTC_graph, errList] = GLTC_graph(Data, OMEGA3,L,alpha, rho,deta, tao, maxIter, epsilon);%GLTC_graph(Data, OMEGA3,L,alpha, rho,deta, maxIter, epsilon);
[psnr_GLTC_graph, ssim_GLTC_graph, fsim_GLTC_graph, ergas_GLTC_graph, msam_GLTC_graph] = MSIQA(Nmsi*255,X_GLTC_graph*255);
figure;imagesc(X_GLTC_graph(:,:,5));title('LRTC-graph')