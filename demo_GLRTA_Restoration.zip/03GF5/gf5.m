gf5baand = double(imread('gf5_005.tif'));
%gf5baand = gf5baand./max(gf5baand(:));
[M,N,p] = size(gf5baand);
OMEGA3 = ones(M,N,p);

bandNum = [42:58,95:114,176:180];

OMEGA3(:,:,bandNum) = 0;

Data = gf5baand.*OMEGA3;
OMEGA3 = logical(OMEGA3);


I1 = gf5baand - min(gf5baand(:));
I1 = I1 ./ max(I1(:));
image = I1;
 

mask = double(OMEGA3);
save('inpainting_GF5.mat','image','mask');



k = 3;
 dim = size(Data);
%  for i =1:length(dim)
%     W_new{i} = zeros(dim{i});
%     Degree{i} = W_new{i};
%     L{i} = W_new{i};
% end
W_new = cell(length(dim), 1);
for i =1:length(dim)
    for j =1:dim(i)%-k
    W(j,j) = 0; 
    W(j,j+1:j+k) = 1; 
    W(j+1:j+k,j) = 1;       
    end
    W_new{i} = W(1:dim(i),1:dim(i));
    Degree{i}=diag((sum(W_new{i},2)));
        L{i} = Degree{i}-W_new{i};
end

%%
maxIter = 500;
alpha = [1e0, 1e0, 1e3];
%alpha = alpha / sum(alpha);

rho = 1e-1;
tao = 1e-3;
deta = [1e-3,1e-3,1e1];
tic
[X_GLTC_graph, errList] = GLTC_graph(Data, OMEGA3,L,alpha, rho,deta, tao, maxIter, epsilon);
%X_GLTC_graph(OMEGA3==1)=Omsi(OMEGA3==1);
GLTC_graph_time=toc;
%[psnr_GLTC_graph, ssim_GLTC_graph, fsim_GLTC_graph, ergas_GLTC_graph, msam_GLTC_graph] = MSIQA(Omsi*255,X_GLTC_graph*255);

%%


figure;imagesc(X_GLTC_graph(:,:,band));

figure;imagesc(gf5baand(:,:,band));title('gf5')


spectral_signature_original = mean(reshape(gf5baand,dim(1)*dim(2),dim(3)));
spectral_signature_GLRTA = mean(reshape(X_GLTC_graph,dim(1)*dim(2),dim(3)));

figure(6)
set(gcf,'Position',[101,101,556,406])
colormap jet
%axes('Position',[0,0,1,1])
bandnumber =1:180;
plot(bandnumber,spectral_signature_original,'LineWidth',1.8,'Color','[0 0 1]');
hold on
plot(bandnumber,spectral_signature_GLRTA,'LineWidth',1.8,'Color','[1 0 0]');
legend('Original Imagery','Restored Imagery','Location','southeast');

%set(gca,'xlim',[1 10],'XTick',1:13,'XTickLabel',{'1e-3' ,'5e-3' ,'1e-2' ,'5e-2','1e-1', '5e-1', '1e0', '5e0', '1e1', '5e1', '1e2', '5e2','1e3'})
%set(gca,'ylim',[1 13],'YTick',1:13,'YTickLabel',{'1e-3' ,'5e-3' ,'1e-2' ,'5e-2','1e-1', '5e-1', '1e0', '5e0', '1e1', '5e1', '1e2', '5e2','1e3'})
xlabel('Band Number','FontSize',12)
ylabel('Average Spectral Signature','FontSize',12)


set(gca, 'Xcolor', [0,0,0]) 
set(gca, 'Ycolor', [0,0,0]) 
grid on
set(gca,'GridLineStyle',':','GridColor','k', 'GridAlpha',0.8)
set(gca,'LineWidth',1)
set(gca,'FontName','Arial','FontSize',10,'FontWeight','bold' )

print -depsc GF5_spectral_sig

figure(6)
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imshow(X_GLTC_graph(:,:,45),[]),axis image, axis off
print -depsc GF5_GLRTA_band45

figure(7)
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imshow(gf5baand(:,:,45),[]),axis image, axis off
print -depsc GF5_original_band45



figure(6)
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imagesc(X_GLTC_graph(:,:,96)),axis image, axis off
print -depsc GF5_GLRTA_band96

figure(7)
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imagesc(gf5baand(:,:,96)),axis image, axis off
print -depsc GF5_original_band96


DIP = (double(pred));
figure(6)
set(gcf,'Position',[101,101,356,356])
colormap jet
axes('Position',[0,0,1,1])
imagesc(DIP(:,:,180)),axis image, axis off
print -depsc GF5_DIP_band180